# 韓系 3D COS 生成器 - Electron 桌面應用打包指南

## 概述

本指南說明如何將網頁版本打包成跨平台桌面應用（Windows/macOS/Linux）。

## 系統要求

- Node.js 16+ 和 pnpm
- 對於 macOS 簽名：需要 Apple Developer 帳號
- 對於 Windows 簽名：需要代碼簽名證書（可選）

## 快速開始

### 1. 開發環境運行

```bash
# 安裝依賴
pnpm install

# 啟動開發服務器和 Electron（並行）
pnpm run electron:dev
```

### 2. 構建桌面應用

#### 全平台構建（需要相應的構建環境）

```bash
# 構建所有平台
pnpm run electron:build
```

#### 特定平台構建

```bash
# Windows
pnpm run electron:build:win

# macOS
pnpm run electron:build:mac

# Linux
pnpm run electron:build:linux
```

## 構建輸出

構建完成後，應用程序將位於 `dist/` 目錄中：

- **Windows**: `dist/COS生成器 Setup 1.0.0.exe` (安裝程序) 和 `dist/COS生成器 1.0.0.exe` (便攜版)
- **macOS**: `dist/COS生成器-1.0.0.dmg` (磁盤鏡像)
- **Linux**: `dist/cos-generator-enhanced-1.0.0.AppImage` 和 `dist/cos-generator-enhanced_1.0.0_amd64.deb`

## 離線功能

應用支援以下離線功能：

- ✅ UI 和參數管理完全離線可用
- ✅ 本地數據持久化（使用 electron-store）
- ✅ 歷史紀錄本地保存
- ✅ 參數預設和自訂設置
- ⚠️ 圖像生成需要網絡連接

## 本地數據存儲

應用使用 `electron-store` 在以下位置存儲本地數據：

- **Windows**: `%APPDATA%\COS生成器\config.json`
- **macOS**: `~/Library/Application Support/COS生成器/config.json`
- **Linux**: `~/.config/COS生成器/config.json`

## 代碼簽名（可選但推薦）

### macOS 簽名

```bash
# 設置環境變量
export CSC_IDENTITY_AUTO_DISCOVERY=false
export CSC_LINK=/path/to/certificate.p12
export CSC_KEY_PASSWORD=your_password

# 構建
pnpm run electron:build:mac
```

### Windows 簽名

```bash
# 設置環境變量
set WIN_CSC_LINK=C:\path\to\certificate.pfx
set WIN_CSC_KEY_PASSWORD=your_password

# 構建
pnpm run electron:build:win
```

## 故障排除

### 構建失敗

1. 清除緩存：`rm -rf dist node_modules && pnpm install`
2. 檢查 Node.js 版本：`node --version` (應為 16+)
3. 檢查 Electron 版本：`pnpm list electron`

### 應用無法啟動

1. 檢查開發服務器是否在運行（開發模式）
2. 檢查 `.manus-logs/` 中的日誌
3. 在終端中直接運行應用查看錯誤信息

### 離線功能不工作

1. 確認 electron-store 已正確初始化
2. 檢查應用數據目錄的寫入權限
3. 查看應用日誌獲取詳細錯誤信息

## 分發

### 自動更新

要啟用自動更新，需要配置 electron-updater：

```bash
pnpm add electron-updater
```

然後在 `electron/main.ts` 中添加更新邏輯。

### 發佈到應用商店

- **Windows Store**: 使用 `electron-builder` 的 `appx` 目標
- **macOS App Store**: 需要 Apple Developer 帳號和特殊簽名
- **Linux**: 發佈到 Flathub 或 Snap Store

## 性能優化

1. **代碼分割**: 已在 Vite 中配置
2. **懶加載**: 使用 React.lazy() 加載組件
3. **緩存**: 使用 electron-store 緩存數據
4. **預加載**: 在 preload.ts 中預加載必要的 API

## 安全建議

1. 啟用上下文隔離（已配置）
2. 禁用 Node 集成（已配置）
3. 使用 preload 腳本進行 IPC 通信（已配置）
4. 驗證所有用戶輸入
5. 定期更新依賴項

## 許可證

MIT

## 支持

如有問題或建議，請提交 Issue。
