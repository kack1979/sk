import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { generateImage } from "../_core/imageGeneration";
import {
  saveGeneratedImage,
  getUserGeneratedImages,
  deleteGeneratedImage,
  saveReferenceImage,
} from "../db";

/**
 * V4 MASTER STYLE - Professional Photography Keywords
 * Replaces all "sexy" terms with high-end portrait photography terminology
 */
const PHOTOGRAPHY_STYLE_WEIGHTS = `(Korean AAA MMORPG Character Design:1.5), (Premium Korean Character Rendering:1.5), (UE5 Character Skin Shader:1.4), (High-End Korean 3D Semi-Realistic Character:1.4), (Game Splash Art Quality:1.4), (Professional Portrait Lighting:1.2)`;

const PHOTOGRAPHY_POSITIVE_KEYWORDS = [
  "(masterpiece, best quality, amazing quality, ultra detailed, absurdres, 8K, HDR)",
  "75% Korean AAA MMORPG Character",
  "25% Premium Professional Portrait Photography",
  "Korean 3D Semi-Realistic Character",
  "Premium Korean Game Character",
  "AAA MMORPG Character Design",
  "AAA Game Splash Art",
  "Unreal Engine 5 Character Rendering",
  "Cinematic CGI",
  "High-End Character Illustration",
  "Luxury Character Artwork",
  "Premium Korean Fantasy Art",
  "Modern Korean Character Aesthetics",
  "beautiful Korean facial proportions",
  "small oval face",
  "soft rounded jawline",
  "slightly full cheeks",
  "delicate chin",
  "gentle youthful adult beauty",
  "natural facial asymmetry",
  "balanced facial features",
  "large almond-shaped eyes",
  "slightly droopy eyes",
  "natural double eyelids",
  "deep crystal iris",
  "realistic iris pattern",
  "soft eyelashes",
  "wet eyes",
  "natural catchlight",
  "premium eye shader",
  "small elegant nose",
  "soft glossy lips",
  "natural lip gradient",
  "subtle smile",
  "gentle expression",
  "Premium Korean UE5 Skin Shader",
  "Ultra Smooth Porcelain Skin",
  "High Quality Subsurface Scattering",
  "SSS",
  "Soft Skin Translucency",
  "Healthy Pink Undertone",
  "Soft Natural Blush",
  "Natural Skin Highlights",
  "Silky Smooth Skin",
  "Luxury Skin Rendering",
  "Fine Skin Gradient",
  "Soft Specular",
  "High-End Character Skin",
  "Ultra Detailed Hair",
  "Individual Hair Strands",
  "Fine Flyaway Hair",
  "Layered Hair",
  "Volumetric Hair",
  "Realistic Hair Shader",
  "PBR Hair",
  "Silky Hair",
  "Natural Hair Scattering",
  "Soft Hair Highlights",
  "Physically Based Rendering",
  "PBR Materials",
  "Realistic Fabric Texture",
  "Luxury Satin",
  "Soft Silk",
  "Organza",
  "Micro Fabric Details",
  "High-End Material Rendering",
  "85mm Portrait Lens",
  "Professional Portrait Composition",
  "Cinematic Composition",
  "Shallow Depth of Field",
  "Luxury Portrait Lighting",
  "Warm Indoor Light",
  "Cool Window Rim Light",
  "Global Illumination",
  "Ray Tracing",
  "Volumetric Lighting",
  "Soft Shadow Transition",
  "High Dynamic Range",
  "Cinematic Color Grading",
  "AAA Promotional Artwork",
  "Highest Quality Character Rendering",
  "Game Key Visual",
  "Luxury Korean Character Illustration",
  "Next Generation Character Rendering",
  "Hyper Detailed Character",
  "Sharp Focus",
];

const PHOTOGRAPHY_NEGATIVE_KEYWORDS = [
  "(worst quality, low quality, normal quality)",
  "lowres",
  "blurry",
  "jpeg artifacts",
  "pixelated",
  "noise",
  "photorealistic",
  "real person",
  "real human",
  "real face",
  "real skin",
  "DSLR",
  "phone camera",
  "selfie",
  "snapshot",
  "fashion model",
  "fashion magazine",
  "runway",
  "editorial photography",
  "beauty influencer",
  "Instagram",
  "TikTok",
  "K-pop idol",
  "celebrity",
  "cosplay",
  "western face",
  "western beauty",
  "aged face",
  "old face",
  "over 25 years old",
  "masculine",
  "child",
  "baby face",
  "anime",
  "2D",
  "manga",
  "comic",
  "cartoon",
  "cel shading",
  "flat color",
  "plastic skin",
  "wax skin",
  "doll",
  "mannequin",
  "rubber skin",
  "visible pores",
  "skin blemishes",
  "acne",
  "freckles",
  "heavy makeup",
  "over sharpen",
  "over saturated",
  "bad anatomy",
  "deformed",
  "mutated",
  "bad hands",
  "extra fingers",
  "missing fingers",
  "cross eye",
  "lazy eye",
  "duplicate",
  "cropped",
  "watermark",
  "logo",
  "signature",
  "text",
];

/**
 * Replace "sexy" and suggestive terms with professional photography terminology
 */
function replaceSensitiveWords(text: string): string {
  const replacements: Record<string, string> = {
    sexy: "artistic and elegant",
    seductive: "captivating and refined",
    revealing: "artistically exposed",
    suggestive: "artistic interpretation",
    "deep cleavage": "artistic chest exposure",
    "plunging neckline": "sophisticated neckline design",
    exposed: "artistically revealed",
    sensual: "graceful and refined",
    provocative: "artistic and bold",
  };

  let result = text;
  for (const [sensitive, replacement] of Object.entries(replacements)) {
    const regex = new RegExp(`\\b${sensitive}\\b`, "gi");
    result = result.replace(regex, replacement);
  }
  return result;
}

/**
 * Build enhanced prompt with V4 MASTER STYLE and age limit
 */
function buildEnhancedPrompt(
  basePrompt: string,
  autoOptimize: boolean
): string {
  if (!autoOptimize) {
    return basePrompt;
  }

  // Add style weights at the beginning
  let enhanced = PHOTOGRAPHY_STYLE_WEIGHTS + ", ";

  // Add base prompt
  enhanced += basePrompt;

  // Add age limit to ensure characters are young (max 25 years old)
  enhanced += ", age 18-25 years old, youthful appearance";

  // Add photography quality keywords
  enhanced += ", " + PHOTOGRAPHY_POSITIVE_KEYWORDS.slice(0, 15).join(", ");

  return enhanced;
}

export const cosImageRouter = router({
  buildPrompt: publicProcedure
    .input(
      z.object({
        hairColor: z.string(),
        eyeColor: z.string(),
        expressions: z.array(z.string()),
        accessories: z.array(z.string()),
        clothing: z.string(),
        scene: z.string().optional(),
        angle: z.string().optional(),
        pose: z.string().optional(),
        bustSize: z.string(),
        customPrompt: z.string().optional(),
        autoOptimize: z.boolean().default(true),
      })
    )
    .mutation(({ input }) => {
      // Build positive prompt with professional photography terminology
      let positivePrompt = `beautiful Korean character, ${input.clothing}, ${input.bustSize} cup`;

      if (input.scene) positivePrompt += `, ${input.scene}`;
      if (input.angle) positivePrompt += `, ${input.angle}`;
      if (input.pose) positivePrompt += `, ${input.pose}`;
      if (input.expressions.length > 0)
        positivePrompt += `, ${input.expressions.join(", ")}`;
      if (input.accessories.length > 0)
        positivePrompt += `, wearing ${input.accessories.join(", ")}`;

      positivePrompt += `, hair color ${input.hairColor}, eye color ${input.eyeColor}`;

      if (input.customPrompt) {
        positivePrompt += `, ${input.customPrompt}`;
      }

      // Replace sensitive words with professional terminology
      positivePrompt = replaceSensitiveWords(positivePrompt);

      // Apply auto-optimize with V4 MASTER STYLE and age limit
      if (input.autoOptimize) {
        positivePrompt = buildEnhancedPrompt(positivePrompt, true);
      }

      // Build negative prompt with age restriction
      let negativePrompt = PHOTOGRAPHY_NEGATIVE_KEYWORDS.join(", ");

      return {
        positivePrompt,
        negativePrompt,
      };
    }),

  generateImage: publicProcedure
    .input(
      z.object({
        positivePrompt: z.string(),
        negativePrompt: z.string(),
        referenceImageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await generateImage({
          prompt: input.positivePrompt,
          originalImages: input.referenceImageUrl
            ? [
                {
                  url: input.referenceImageUrl,
                  mimeType: "image/jpeg",
                },
              ]
            : undefined,
        });

        return {
          imageUrl: result.url,
          success: true,
        };
      } catch (error) {
        throw new Error(
          `Failed to generate image: ${error instanceof Error ? error.message : "Unknown error"}`
        );
      }
    }),

  saveImage: protectedProcedure
    .input(
      z.object({
        imageUrl: z.string(),
        positivePrompt: z.string(),
        negativePrompt: z.string(),
        params: z.record(z.string(), z.any()),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await saveGeneratedImage(
          ctx.user.id,
          input.imageUrl,
          input.positivePrompt,
          input.negativePrompt,
          input.params
        );

        return {
          success: true,
          id: (result as any).insertId?.toString() || Date.now().toString(),
        };
      } catch (error) {
        throw new Error(
          `Failed to save image: ${error instanceof Error ? error.message : "Unknown error"}`
        );
      }
    }),

  getHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input, ctx }) => {
      try {
        const images = await getUserGeneratedImages(
          ctx.user.id,
          input.limit,
          input.offset
        );
        return images;
      } catch (error) {
        console.error("Failed to get history:", error);
        return [];
      }
    }),

  deleteImage: protectedProcedure
    .input(z.object({ imageId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        await deleteGeneratedImage(input.imageId, ctx.user.id);
        return { success: true };
      } catch (error) {
        throw new Error(
          `Failed to delete image: ${error instanceof Error ? error.message : "Unknown error"}`
        );
      }
    }),

  uploadReferenceImage: protectedProcedure
    .input(
      z.object({
        imageUrl: z.string(),
        filename: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await saveReferenceImage(
          ctx.user.id,
          input.imageUrl
        );
        return {
          success: true,
          id: (result as any).insertId?.toString() || Date.now().toString(),
        };
      } catch (error) {
        throw new Error(
          `Failed to upload reference image: ${error instanceof Error ? error.message : "Unknown error"}`
        );
      }
    }),
});
