# 韓系 3D COS 生成器 - 桌面應用完整設置指南

## 📋 目錄

1. [快速開始](#快速開始)
2. [開發環境](#開發環境)
3. [本地運行](#本地運行)
4. [打包應用](#打包應用)
5. [分發](#分發)
6. [故障排除](#故障排除)

---

## 快速開始

### 系統要求

- **Node.js**: 16.0.0 或更高版本
- **pnpm**: 8.0.0 或更高版本
- **操作系統**: Windows 10+, macOS 10.13+, 或 Linux (Ubuntu 18.04+)

### 安裝步驟

```bash
# 1. 克隆或進入項目目錄
cd cos-generator-enhanced

# 2. 安裝依賴
pnpm install

# 3. 啟動開發環境
pnpm run electron:dev
```

---

## 開發環境

### 項目結構

```
cos-generator-enhanced/
├── client/                 # React 前端代碼
│   ├── src/
│   │   ├── pages/         # 頁面組件
│   │   ├── components/    # UI 組件
│   │   └── ...
│   └── index.html
├── server/                 # Express 後端代碼
│   ├── routers/           # tRPC 路由
│   ├── db.ts              # 數據庫操作
│   └── ...
├── electron/              # Electron 主進程代碼
│   ├── main.ts            # 主進程入口
│   └── preload.ts         # 預加載腳本
├── drizzle/               # 數據庫架構
├── package.json           # 項目配置
└── electron-builder.yml   # Electron 構建配置
```

### 開發命令

```bash
# 啟動開發服務器（包含 Electron）
pnpm run electron:dev

# 僅啟動 Web 開發服務器
pnpm run dev

# 類型檢查
pnpm run check

# 代碼格式化
pnpm run format

# 運行測試
pnpm run test
```

---

## 本地運行

### 方式 1：開發模式（推薦用於開發）

```bash
pnpm run electron:dev
```

這將：
1. 啟動 Vite 開發服務器（http://localhost:5173）
2. 啟動 Express 後端服務器
3. 打開 Electron 窗口並連接到開發服務器
4. 自動重新加載代碼更改

### 方式 2：生產模式（測試最終應用）

```bash
# 構建 Web 和後端
pnpm run build

# 在 Electron 中運行生產版本
electron .
```

---

## 打包應用

### 全平台構建

```bash
# 構建所有支援的平台
pnpm run electron:build
```

### 特定平台構建

```bash
# 僅構建 Windows
pnpm run electron:build:win

# 僅構建 macOS
pnpm run electron:build:mac

# 僅構建 Linux
pnpm run electron:build:linux
```

### 構建輸出

構建完成後，應用程序將位於 `dist/` 目錄：

| 平台 | 文件 | 說明 |
|------|------|------|
| Windows | `COS生成器 Setup 1.0.0.exe` | 安裝程序（推薦） |
| Windows | `COS生成器 1.0.0.exe` | 便攜版（無需安裝） |
| macOS | `COS生成器-1.0.0.dmg` | 磁盤鏡像 |
| Linux | `cos-generator-enhanced-1.0.0.AppImage` | AppImage 格式 |
| Linux | `cos-generator-enhanced_1.0.0_amd64.deb` | Debian 包 |

---

## 分發

### Windows

1. **安裝程序版本**：
   - 用戶下載 `COS生成器 Setup 1.0.0.exe`
   - 雙擊運行安裝程序
   - 選擇安裝位置和開始菜單快捷方式
   - 完成安裝

2. **便攜版本**：
   - 用戶下載 `COS生成器 1.0.0.exe`
   - 無需安裝，直接運行
   - 可放在 USB 驅動器上使用

### macOS

1. 用戶下載 `COS生成器-1.0.0.dmg`
2. 雙擊打開磁盤鏡像
3. 將應用拖到 Applications 文件夾
4. 從 Applications 或 Launchpad 啟動

### Linux

**使用 AppImage**：
```bash
# 下載後
chmod +x cos-generator-enhanced-1.0.0.AppImage
./cos-generator-enhanced-1.0.0.AppImage
```

**使用 Debian 包**：
```bash
sudo dpkg -i cos-generator-enhanced_1.0.0_amd64.deb
# 然後從應用菜單啟動
```

---

## 離線功能

應用支援以下離線功能：

### ✅ 完全離線可用

- 🎨 UI 界面和所有參數選擇器
- 💾 本地數據存儲和歷史紀錄
- ⚙️ 應用設置和用戶偏好
- 📋 參數預設和自訂配置

### ⚠️ 需要網絡連接

- 🖼️ AI 圖像生成（調用 Manus API）
- 🔐 用戶認證（Manus OAuth）
- ☁️ 雲端同步（如果啟用）

### 本地數據存儲位置

應用數據存儲在以下位置：

- **Windows**: `%APPDATA%\COS生成器\config.json`
- **macOS**: `~/Library/Application Support/COS生成器/config.json`
- **Linux**: `~/.config/COS生成器/config.json`

---

## 故障排除

### 應用無法啟動

**症狀**：點擊應用圖標無反應

**解決方案**：
1. 檢查 Node.js 版本：`node --version`（應為 16+）
2. 在終端中直接運行應用查看錯誤信息
3. 檢查防火牆設置

### 開發模式中應用無法連接到服務器

**症狀**：開發模式中應用顯示空白或連接錯誤

**解決方案**：
1. 確認 Vite 開發服務器在運行（http://localhost:5173）
2. 檢查防火牆是否阻止 localhost 連接
3. 重啟開發服務器：`pnpm run electron:dev`

### 圖像生成失敗

**症狀**：點擊生成按鈕後無反應或顯示錯誤

**解決方案**：
1. 檢查網絡連接
2. 驗證 API 密鑰配置
3. 檢查 API 配額限制
4. 查看應用日誌獲取詳細錯誤

### 本地數據丟失

**症狀**：重啟應用後歷史紀錄消失

**解決方案**：
1. 檢查應用數據目錄是否存在
2. 驗證目錄寫入權限
3. 查看應用日誌中的存儲錯誤

### 構建失敗

**症狀**：`pnpm run electron:build` 失敗

**解決方案**：
```bash
# 清除緩存並重新安裝
rm -rf dist node_modules
pnpm install

# 重新構建
pnpm run electron:build
```

---

## 高級配置

### 自動更新

要啟用自動更新功能：

1. 安裝 electron-updater：
   ```bash
   pnpm add electron-updater
   ```

2. 在 `electron/main.ts` 中添加更新邏輯

3. 配置更新服務器（GitHub Releases、S3 等）

### 代碼簽名

#### macOS 簽名

```bash
export CSC_IDENTITY_AUTO_DISCOVERY=false
export CSC_LINK=/path/to/certificate.p12
export CSC_KEY_PASSWORD=your_password

pnpm run electron:build:mac
```

#### Windows 簽名

```bash
set WIN_CSC_LINK=C:\path\to\certificate.pfx
set WIN_CSC_KEY_PASSWORD=your_password

pnpm run electron:build:win
```

---

## 性能優化

### 應用啟動時間

- 使用代碼分割減少初始包大小
- 啟用 V8 代碼緩存
- 預加載常用模塊

### 內存使用

- 定期清理未使用的數據
- 使用虛擬化列表顯示大型列表
- 實現適當的垃圾回收

### 網絡性能

- 實現請求緩存
- 使用 CDN 加速資源加載
- 壓縮傳輸數據

---

## 安全建議

1. ✅ 啟用上下文隔離（已配置）
2. ✅ 禁用 Node 集成（已配置）
3. ✅ 使用 preload 腳本（已配置）
4. 🔒 驗證所有用戶輸入
5. 🔒 定期更新依賴項
6. 🔒 使用 HTTPS 進行 API 通信
7. 🔒 不在客戶端存儲敏感信息

---

## 許可證

MIT

---

## 支持

如有問題或建議，請查看：
- 項目文檔：`ELECTRON_BUILD_GUIDE.md`
- 應用日誌：應用數據目錄中的 `logs/` 文件夾
- 官方文檔：https://www.electronjs.org/docs

---

**最後更新**：2026-07-21
**版本**：1.0.0
