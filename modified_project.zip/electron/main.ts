import { app, BrowserWindow, Menu, ipcMain, dialog } from "electron";
import path from "path";
import isDev from "electron-is-dev";
import Store from "electron-store";
import * as fs from "fs";

// Initialize electron-store for local data persistence
const store = new Store();

let mainWindow: BrowserWindow | null = null;

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  const startUrl = isDev
    ? "http://localhost:5173"
    : `file://${path.join(__dirname, "../dist/public/index.html")}`;

  mainWindow.loadURL(startUrl).catch((err) => {
    console.error("Failed to load URL:", err);
  });

  // 隱藏 Menu Bar
  mainWindow.setMenuBarVisibility(false);

  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
};

app.on("ready", createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// IPC handlers for local storage and offline functionality
ipcMain.handle("store:get", (event, key: string) => {
  return store.get(key);
});

ipcMain.handle("store:set", (event, key: string, value: any) => {
  store.set(key, value);
});

ipcMain.handle("store:delete", (event, key: string) => {
  store.delete(key);
});

ipcMain.handle("store:clear", () => {
  store.clear();
});

// Get app version
ipcMain.handle("app:getVersion", () => {
  return app.getVersion();
});

// Get app path
ipcMain.handle("app:getPath", (event, name: string) => {
  return app.getPath(name as any);
});

// Create application menu
const createMenu = () => {
  const template: any = [
    {
      label: "File",
      submenu: [
        {
          label: "Exit",
          accelerator: "CmdOrCtrl+Q",
          click: () => {
            app.quit();
          },
        },
      ],
    },
    {
      label: "Edit",
      submenu: [
        { label: "Undo", accelerator: "CmdOrCtrl+Z", role: "undo" },
        { label: "Redo", accelerator: "CmdOrCtrl+Y", role: "redo" },
        { type: "separator" },
        { label: "Cut", accelerator: "CmdOrCtrl+X", role: "cut" },
        { label: "Copy", accelerator: "CmdOrCtrl+C", role: "copy" },
        { label: "Paste", accelerator: "CmdOrCtrl+V", role: "paste" },
      ],
    },
    {
      label: "View",
      submenu: [
        { label: "Reload", accelerator: "CmdOrCtrl+R", role: "reload" },
        {
          label: "Force Reload",
          accelerator: "CmdOrCtrl+Shift+R",
          role: "forceReload",
        },
        { label: "Toggle DevTools", accelerator: "F12", role: "toggleDevTools" },
      ],
    },
    {
      label: "Help",
      submenu: [
        {
          label: "About",
          click: () => {
            dialog.showMessageBox(mainWindow!, {
              type: "info",
              title: "韓系 3D COS 生成器",
              message: "韓系 3D COS 生成器",
              detail: `版本: ${app.getVersion()}\n\n完整的 AI 驅動的角色圖像生成工具`,
            });
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
};

// app.on("ready", createMenu); // 依照要求關閉 Menu Bar
