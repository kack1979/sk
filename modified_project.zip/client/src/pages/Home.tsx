import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, Loader2, X, Upload, Image as ImageIcon, History, Sparkles, Eye } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { generateRandomInspiration, buildEnhancedPromptWithWeights, replaceSensitiveWords, buildNegativePrompt, formatPromptForDisplay } from "@/lib/promptGenerator";
import { Slider } from "@/components/ui/slider";

// Types
interface GeneratedImage {
  id: string;
  url: string;
  timestamp: number;
  params: any;
}

interface ReferenceImage {
  id: string;
  url: string;
  timestamp: number;
}

// Clothing options
const clothingOptions = {
  禮服: [
    "公主裙",
    "開高衩禮服",
    "深V禮服",
    "大腿高衩禮服",
    "露背禮服",
    "魚尾裙",
    "黑色馬甲裙",
    "紅色禮服",
    "蕾絲禮服",
    "A字禮服",
  ],
  制服: [
    "韓系學院風",
    "偶像舞台制服",
    "COS女警",
    "COS水手服",
    "護士制服",
    "女僕制服",
    "空姐制服",
    "警察制服",
  ],
  COSPLAY: [
    "旗袍",
    "漢服",
    "和服",
    "女戰士",
    "魔法少女",
    "哥德蘿莉塔",
    "洛麗塔",
    "忍者",
    "科幻戰士",
    "動漫角色",
  ],
  泳裝: [
    "單件泳衣",
    "比基尼",
    "綁帶泳裝",
    "三角比基尼",
    "蕾絲泳裝",
    "高叉泳裝",
    "衝浪泳裝",
    "碎花泳裝",
  ],
  襪子: [
    "過膝襪",
    "白絲襪",
    "黑絲襪",
    "亮面絲襪",
    "漁網襪",
    "吊帶襪",
    "小腿襪",
    "彩色條紋襪",
  ],
  鞋子: [
    "平底鞋",
    "涼鞋",
    "高跟鞋",
    "馬丁靴",
    "厚底鞋",
    "運動鞋",
    "長筒靴",
    "芭蕾鞋",
  ],
  特殊風格: [
    "賽博龐克",
    "復古風",
    "黑白極簡",
    "日系JK制服",
    "蘿莉塔",
    "龐克搖滾",
    "波西米亞",
    "暗黑哥特",
  ],
};

// Color presets
const hairColorPresets = [
  "#FFD700", "#FFA500", "#FF6B6B", "#FF1493", "#8B4513", "#000000",
  "#FFFFFF", "#C0C0C0", "#4B0082", "#00CED1", "#FF69B4", "#32CD32",
];

const eyeColorPresets = [
  "#8B4513", "#000000", "#0000FF", "#00FF00", "#FFD700", "#FF6B6B",
  "#FF1493", "#00CED1", "#9370DB", "#FF8C00", "#20B2AA", "#FF69B4",
];

// Color Picker Component
function ColorPickerSimple({
  value,
  onChange,
  label,
  presets,
}: {
  value: string;
  onChange: (color: string) => void;
  label: string;
  presets: string[];
}) {
  const [showPicker, setShowPicker] = useState(false);

  return (
    <div className="space-y-2">
      <Label className="text-sm font-semibold">{label}</Label>
      <div className="flex gap-2 items-center">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-12 h-10 rounded cursor-pointer border-2 border-accent"
        />
        <span className="text-sm flex-1 font-mono">{value}</span>
        <Button
          size="sm"
          onClick={() => setShowPicker(!showPicker)}
          className="bg-accent hover:bg-accent/90 text-accent-foreground"
        >
          {showPicker ? "隱藏" : "預設"}
        </Button>
      </div>

      {showPicker && (
        <div className="grid grid-cols-6 gap-2 p-3 bg-card rounded-lg border border-border">
          {presets.map((preset) => (
            <button
              key={preset}
              onClick={() => {
                onChange(preset);
                setShowPicker(false);
              }}
              className={cn(
                "w-full h-8 rounded border-2 transition hover:scale-110",
                value === preset
                  ? "border-accent shadow-lg shadow-accent/50"
                  : "border-border hover:border-accent"
              )}
              style={{ backgroundColor: preset }}
              title={preset}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Lightbox Component
function ImageLightbox({
  isOpen,
  imageUrl,
  onClose,
  onDownload,
  onDelete,
}: {
  isOpen: boolean;
  imageUrl: string;
  onClose: () => void;
  onDownload: (url: string) => void;
  onDelete?: () => void;
}) {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex flex-col items-center justify-center"
      onClick={onClose}
    >
      <div
        className="relative w-full h-full max-w-6xl max-h-[90vh] flex items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={imageUrl}
          alt="preview"
          className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
        />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 bg-destructive hover:bg-destructive/90 text-destructive-foreground p-2 rounded-full transition shadow-lg"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 flex justify-center gap-4">
        <Button
          onClick={() => onDownload(imageUrl)}
          className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-6 py-2 rounded-lg flex items-center gap-2"
        >
          <Download className="w-5 h-5" />
          下載
        </Button>

        {onDelete && (
          <Button
            onClick={onDelete}
            className="bg-destructive hover:bg-destructive/90 text-destructive-foreground font-semibold px-6 py-2 rounded-lg"
          >
            刪除
          </Button>
        )}

        <Button
          onClick={onClose}
          className="bg-muted hover:bg-muted/80 text-muted-foreground font-semibold px-6 py-2 rounded-lg"
        >
          關閉
        </Button>
      </div>

      <div className="absolute top-4 left-4 text-foreground/70 text-sm">
        點擊背景或按「關閉」退出預覽
      </div>
    </div>
  );
}

export default function Home() {
  const { user, loading: authLoading } = useAuth();

  // State for parameters
  const [hairColor, setHairColor] = useState("#FFD700");
  const [eyeColor, setEyeColor] = useState("#8B4513");
  const [selectedExpressions, setSelectedExpressions] = useState<string[]>([]);
  const [selectedAccessories, setSelectedAccessories] = useState<string[]>([]);
  const [selectedClothing, setSelectedClothing] = useState<string>("");
  const [selectedClothingCategory, setSelectedClothingCategory] = useState<string>("禮服");
  const [selectedScene, setSelectedScene] = useState<string>("");
  const [selectedAngle, setSelectedAngle] = useState<string>("");
  const [selectedPoses, setSelectedPoses] = useState<string[]>([]);
  const [selectedBustSize, setSelectedBustSize] = useState<string>("D");
  const [customPrompt, setCustomPrompt] = useState("");
  const [autoOptimize, setAutoOptimize] = useState(true);
  const [weightMultiplier, setWeightMultiplier] = useState(1.0);
  const [previewPrompt, setPreviewPrompt] = useState<{ positive: string; negative: string } | null>(null);
  const [showPromptPreview, setShowPromptPreview] = useState(false);

  // State for images
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  const [referenceImages, setReferenceImages] = useState<ReferenceImage[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationCount, setGenerationCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  // Check if running in Electron
  const isElectron = typeof window !== 'undefined' && navigator.userAgent.toLowerCase().includes('electron');

  // Load history from electron-store if available
  useEffect(() => {
    if (isElectron && (window as any).electron) {
      const loadLocalData = async () => {
        try {
          const history = await (window as any).electron.store.get('generatedImages');
          if (history && Array.isArray(history)) {
            setGeneratedImages(history);
            setTotalCount(history.length);
          }
        } catch (error) {
          console.error("Failed to load local history:", error);
        }
      };
      loadLocalData();
    }
  }, [isElectron]);

  // Save history to electron-store whenever generatedImages changes
  useEffect(() => {
    if (isElectron && (window as any).electron) {
      (window as any).electron.store.set('generatedImages', generatedImages);
    }
  }, [generatedImages, isElectron]);

  // Lightbox state
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState("");
  const [lightboxImageId, setLightboxImageId] = useState<string>("");

  // Options
  const expressionOptions = ["微笑", "嚴肅", "調皮", "性感", "溫柔", "兇悍"];
  const accessoriesOptions = [
    "眼鏡", "帽子", "項鍊", "耳環", "蝴蝶結", "手鐲", "戒指", "髮夾",
  ];
  const sceneOptions = [
    "海灘", "時尚寫真", "校園", "晚宴", "居家", "戲劇", "水手風格", "女僕風格", "泳池派對",
  ];
  const angleOptions = ["平拍", "俯視", "仰視", "側面", "3/4", "背後"];
  const poseOptions = ["站立", "坐姿", "躺姿", "側身", "蹲姿", "動感", "特寫"];
  const bustSizeOptions = ["D", "E", "F", "G", "H", "I", "J", "K"];

  // tRPC mutations
  const buildPromptMutation = trpc.cosImage.buildPrompt.useMutation();
  const generateImageMutation = trpc.cosImage.generateImage.useMutation();
  const saveImageMutation = trpc.cosImage.saveImage.useMutation();

  // Toggle handlers
  const toggleExpression = (expr: string) => {
    setSelectedExpressions((prev) =>
      prev.includes(expr) ? prev.filter((e) => e !== expr) : [...prev, expr]
    );
  };

  const toggleAccessory = (acc: string) => {
    setSelectedAccessories((prev) =>
      prev.includes(acc) ? prev.filter((a) => a !== acc) : [...prev, acc]
    );
  };

  const togglePose = (pose: string) => {
    setSelectedPoses((prev) =>
      prev.includes(pose) ? prev.filter((p) => p !== pose) : [...prev, pose]
    );
  };

  // Generate random inspiration
  const handleRandomInspiration = () => {
    const inspiration = generateRandomInspiration();
    setCustomPrompt(inspiration);
    toast.success("已生成隨機靈感提示詞！");
  };

  // Preview prompt
  const handlePreviewPrompt = async () => {
    if (!selectedClothing) {
      toast.error("請先選擇服裝類型");
      return;
    }

    try {
      const result = await buildPromptMutation.mutateAsync({
        hairColor,
        eyeColor,
        expressions: selectedExpressions,
        accessories: selectedAccessories,
        clothing: selectedClothing,
        scene: selectedScene,
        angle: selectedAngle,
        pose: selectedPoses[0] || "",
        bustSize: selectedBustSize,
        customPrompt,
        autoOptimize,
      });

      // Apply weight adjustment
      const enhancedPositive = buildEnhancedPromptWithWeights(result.positivePrompt, weightMultiplier);
      const finalPositive = replaceSensitiveWords(enhancedPositive);

      setPreviewPrompt({
        positive: finalPositive,
        negative: result.negativePrompt,
      });
      setShowPromptPreview(true);
    } catch (error) {
      toast.error("預覽失敗");
    }
  };

  // Copy to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("已複製到剪貼板！");
  };

  // Reference image upload
  const handleReferenceImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        setReferenceImages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            url,
            timestamp: Date.now(),
          },
        ]);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeReferenceImage = (id: string) => {
    setReferenceImages((prev) => prev.filter((img) => img.id !== id));
  };

  const removeGeneratedImage = (id: string) => {
    setGeneratedImages((prev) => prev.filter((img) => img.id !== id));
  };

  // Generate image
  const handleGenerateImage = async () => {
    if (!selectedClothing) {
      toast.error("請先選擇服裝類型");
      return;
    }

    setIsGenerating(true);
    try {
      const promptResult = await buildPromptMutation.mutateAsync({
        hairColor,
        eyeColor,
        expressions: selectedExpressions,
        accessories: selectedAccessories,
        clothing: selectedClothing,
        scene: selectedScene,
        angle: selectedAngle,
        pose: selectedPoses.join(", "),
        bustSize: selectedBustSize,
        customPrompt,
        autoOptimize,
      });

      const imageResult = await generateImageMutation.mutateAsync({
        positivePrompt: promptResult.positivePrompt,
        negativePrompt: promptResult.negativePrompt,
        referenceImageUrl: referenceImages[0]?.url || "",
      });

      const imageUrl = imageResult.imageUrl || "";
      const newImage: GeneratedImage = {
        id: Date.now().toString(),
        url: imageUrl,
        timestamp: Date.now(),
        params: {
          hairColor,
          eyeColor,
          expressions: selectedExpressions,
          accessories: selectedAccessories,
          clothing: selectedClothing,
          scene: selectedScene,
          angle: selectedAngle,
          poses: selectedPoses,
          bustSize: selectedBustSize,
          customPrompt,
        },
      };

      setGeneratedImages((prev) => [newImage, ...prev]);
      setGenerationCount((prev) => prev + 1);
      setTotalCount((prev) => prev + 1);

      // Save to database if user is logged in, or handled by useEffect for local store in Electron
      if (user && !isElectron) {
        try {
          await saveImageMutation.mutateAsync({
            imageUrl: imageUrl,
            positivePrompt: promptResult.positivePrompt,
            negativePrompt: promptResult.negativePrompt,
            params: newImage.params,
          });
        } catch (error) {
          console.warn("Failed to save image to database:", error);
        }
      }

      toast.success("圖像生成成功！");
    } catch (error) {
      console.error("Generation error:", error);
      toast.error(
        `生成失敗: ${error instanceof Error ? error.message : "未知錯誤"}`
      );
    } finally {
      setIsGenerating(false);
    }
  };

  // Download image
  const handleDownloadImage = (url: string) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = `cos-image-${Date.now()}.png`;
    link.click();
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-screen flex-col lg:flex-row">
        {/* Left Panel - Parameters */}
        <div className="w-full lg:w-96 overflow-y-auto bg-card border-r border-border p-6">
          <div className="space-y-6">
            {/* Header */}
            <div>
              <h1 className="text-2xl font-bold text-foreground mb-2">
                韓系 3D COS 生成器
              </h1>
              <p className="text-sm text-muted-foreground">
                自訂參數生成精美的 COS 風格圖像
              </p>
            </div>

            {/* Auth Status */}
            {!user && (
              <Card className="bg-accent/10 border-accent/30 p-4">
                <p className="text-sm text-foreground mb-3">
                  登入後可保存生成歷史
                </p>
                <Button
                  onClick={() => startLogin()}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  登入
                </Button>
              </Card>
            )}

            {/* Generation Counter */}
            <Card className="bg-card border-border p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">今日生成</p>
                  <p className="text-2xl font-bold text-accent">
                    {generationCount}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">總計生成</p>
                  <p className="text-2xl font-bold text-accent">
                    {totalCount}
                  </p>
                </div>
              </div>
            </Card>

            {/* Hair Color */}
            <ColorPickerSimple
              value={hairColor}
              onChange={setHairColor}
              label="髮色"
              presets={hairColorPresets}
            />

            {/* Eye Color */}
            <ColorPickerSimple
              value={eyeColor}
              onChange={setEyeColor}
              label="眼睛顏色"
              presets={eyeColorPresets}
            />

            {/* Expressions */}
            <div>
              <Label className="text-sm font-semibold mb-3 block">表情</Label>
              <div className="grid grid-cols-2 gap-2">
                {expressionOptions.map((expr) => (
                  <label key={expr} className="flex items-center gap-2 cursor-pointer">
                    <Checkbox
                      checked={selectedExpressions.includes(expr)}
                      onCheckedChange={() => toggleExpression(expr)}
                    />
                    <span className="text-sm">{expr}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Accessories */}
            <div>
              <Label className="text-sm font-semibold mb-3 block">飾品</Label>
              <div className="grid grid-cols-2 gap-2">
                {accessoriesOptions.map((acc) => (
                  <label key={acc} className="flex items-center gap-2 cursor-pointer">
                    <Checkbox
                      checked={selectedAccessories.includes(acc)}
                      onCheckedChange={() => toggleAccessory(acc)}
                    />
                    <span className="text-sm">{acc}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Clothing */}
            <div>
              <Label className="text-sm font-semibold mb-2">服裝分類</Label>
              <Select value={selectedClothingCategory} onValueChange={setSelectedClothingCategory}>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(clothingOptions).map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Label className="text-sm font-semibold mb-2 block mt-3">服裝選擇</Label>
              <Select value={selectedClothing} onValueChange={setSelectedClothing}>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue placeholder="選擇服裝" />
                </SelectTrigger>
                <SelectContent>
                  {(clothingOptions[selectedClothingCategory as keyof typeof clothingOptions] ?? []).map((item) => (
                    <SelectItem key={item} value={item}>
                      {item}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Scene */}
            <div>
              <Label className="text-sm font-semibold mb-2">場景</Label>
              <Select value={selectedScene} onValueChange={setSelectedScene}>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue placeholder="選擇場景" />
                </SelectTrigger>
                <SelectContent>
                  {sceneOptions.map((scene) => (
                    <SelectItem key={scene} value={scene}>
                      {scene}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Angle */}
            <div>
              <Label className="text-sm font-semibold mb-2">角度</Label>
              <Select value={selectedAngle} onValueChange={setSelectedAngle}>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue placeholder="選擇角度" />
                </SelectTrigger>
                <SelectContent>
                  {angleOptions.map((angle) => (
                    <SelectItem key={angle} value={angle}>
                      {angle}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Poses */}
            <div>
              <Label className="text-sm font-semibold mb-3 block">姿勢</Label>
              <div className="grid grid-cols-2 gap-2">
                {poseOptions.map((pose) => (
                  <label key={pose} className="flex items-center gap-2 cursor-pointer">
                    <Checkbox
                      checked={selectedPoses.includes(pose)}
                      onCheckedChange={() => togglePose(pose)}
                    />
                    <span className="text-sm">{pose}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Bust Size */}
            <div>
              <Label className="text-sm font-semibold mb-2">罩杯大小</Label>
              <Select value={selectedBustSize} onValueChange={setSelectedBustSize}>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {bustSizeOptions.map((size) => (
                    <SelectItem key={size} value={size}>
                      {size} Cup
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Custom Prompt */}
            <div>
              <Label className="text-sm font-semibold mb-2">自訂提示詞</Label>
              <Textarea
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="輸入額外的描述詞彙..."
                className="bg-input border-border text-sm"
                rows={3}
              />
            </div>

            {/* Auto Optimize */}
            <label className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={autoOptimize}
                onCheckedChange={(checked) => setAutoOptimize(checked as boolean)}
              />
              <span className="text-sm font-semibold">自動優化（加入韓系 3D 風格）</span>
            </label>

            {/* Reference Image Upload */}
            <div>
              <Label className="text-sm font-semibold mb-2 block">參考圖上傳</Label>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleReferenceImageUpload}
                  className="hidden"
                  id="ref-image-input"
                />
                <label
                  htmlFor="ref-image-input"
                  className="flex items-center justify-center gap-2 w-full p-3 border-2 border-dashed border-border rounded-lg cursor-pointer hover:border-accent transition"
                >
                  <Upload className="w-4 h-4" />
                  <span className="text-sm">點擊上傳參考圖</span>
                </label>
              </div>

              {referenceImages.length > 0 && (
                <div className="mt-3 space-y-2">
                  {referenceImages.map((img) => (
                    <div key={img.id} className="flex items-center gap-2 p-2 bg-card rounded border border-border">
                      <img src={img.url} alt="ref" className="w-10 h-10 rounded object-cover" />
                      <span className="text-xs flex-1 truncate">參考圖</span>
                      <button
                        onClick={() => removeReferenceImage(img.id)}
                        className="text-destructive hover:text-destructive/80"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Weight Adjustment Slider */}
            <div className="mt-4 space-y-2 bg-card p-4 rounded-lg border border-border">
              <div className="flex justify-between items-center">
                <Label className="text-sm font-semibold">權重調整</Label>
                <span className="text-xs text-muted-foreground font-mono">{weightMultiplier.toFixed(1)}x</span>
              </div>
              <Slider
                value={[weightMultiplier]}
                onValueChange={(value) => setWeightMultiplier(value[0])}
                min={0.5}
                max={2.0}
                step={0.1}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">調整攝影和光線關鍵字的影響力（0.5x - 2.0x）</p>
            </div>

            {/* Random Inspiration & Preview Buttons */}
            <div className="flex gap-2 mt-4">
              <Button
                onClick={handleRandomInspiration}
                variant="outline"
                className="flex-1"
              >
                <Sparkles className="mr-2 h-4 w-4" />
                隨機靈感
              </Button>
              <Button
                onClick={handlePreviewPrompt}
                variant="outline"
                className="flex-1"
              >
                <Eye className="mr-2 h-4 w-4" />
                預覽提示詞
              </Button>
            </div>

            {/* Generate Button */}
            <Button
              onClick={handleGenerateImage}
              disabled={isGenerating || !selectedClothing}
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-6 text-lg"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  生成中...
                </>
              ) : (
                <>
                  <ImageIcon className="w-5 h-5 mr-2" />
                  生成圖像
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Right Panel - Preview & History */}
        <div className="flex-1 overflow-y-auto bg-background p-6">
          <Tabs defaultValue="preview" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-card border border-border">
              <TabsTrigger value="preview" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <ImageIcon className="w-4 h-4 mr-2" />
                預覽
              </TabsTrigger>
              <TabsTrigger value="history" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <History className="w-4 h-4 mr-2" />
                歷史
              </TabsTrigger>
            </TabsList>

            {/* Preview Tab */}
            <TabsContent value="preview" className="mt-6">
              {generatedImages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <ImageIcon className="w-16 h-16 text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">還沒有生成任何圖像</p>
                  <p className="text-sm text-muted-foreground/70">調整參數後點擊「生成圖像」開始</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {generatedImages.map((img) => (
                    <div
                      key={img.id}
                      className="group relative aspect-square rounded-lg overflow-hidden bg-card border border-border cursor-pointer hover:border-accent transition"
                      onClick={() => {
                        setLightboxImage(img.url);
                        setLightboxImageId(img.id);
                        setLightboxOpen(true);
                      }}
                    >
                      <img
                        src={img.url}
                        alt="generated"
                        className="w-full h-full object-cover group-hover:scale-105 transition"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadImage(img.url);
                          }}
                          className="bg-accent hover:bg-accent/90 text-accent-foreground"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeGeneratedImage(img.id);
                          }}
                          className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* History Tab */}
            <TabsContent value="history" className="mt-6">
              {(!user && !isElectron) ? (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <History className="w-16 h-16 text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">登入後可查看生成歷史</p>
                  <Button
                    onClick={() => startLogin()}
                    className="mt-4 bg-accent hover:bg-accent/90 text-accent-foreground"
                  >
                    登入
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">生成歷史 ({generatedImages.length})</h3>
                    {isElectron && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          if (confirm("確定要清除所有歷史記錄嗎？")) {
                            setGeneratedImages([]);
                          }
                        }}
                      >
                        清除全部
                      </Button>
                    )}
                  </div>
                  {generatedImages.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      <p>尚無歷史記錄</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      {generatedImages.map((img) => (
                        <div
                          key={img.id}
                          className="group relative aspect-square rounded-md overflow-hidden bg-card border border-border cursor-pointer hover:border-accent transition"
                          onClick={() => {
                            setLightboxImage(img.url);
                            setLightboxImageId(img.id);
                            setLightboxOpen(true);
                          }}
                        >
                          <img
                            src={img.url}
                            alt="history"
                            className="w-full h-full object-cover group-hover:scale-105 transition"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Lightbox */}
      <ImageLightbox
        isOpen={lightboxOpen}
        imageUrl={lightboxImage}
        onClose={() => setLightboxOpen(false)}
        onDownload={handleDownloadImage}
        onDelete={() => {
          removeGeneratedImage(lightboxImageId);
          setLightboxOpen(false);
        }}
      />

      {/* Prompt Preview Modal */}
      {showPromptPreview && previewPrompt && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto bg-background">
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold">提示詞預覽</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPromptPreview(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Positive Prompt */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label className="font-semibold text-green-600">正向提示詞</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(previewPrompt.positive)}
                  >
                    複製
                  </Button>
                </div>
                <div className="bg-muted p-3 rounded-lg text-sm whitespace-pre-wrap break-words font-mono text-xs max-h-64 overflow-y-auto">
                  {formatPromptForDisplay(previewPrompt.positive)}
                </div>
              </div>

              {/* Negative Prompt */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label className="font-semibold text-red-600">負向提示詞</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(previewPrompt.negative)}
                  >
                    複製
                  </Button>
                </div>
                <div className="bg-muted p-3 rounded-lg text-sm whitespace-pre-wrap break-words font-mono text-xs max-h-64 overflow-y-auto">
                  {formatPromptForDisplay(previewPrompt.negative)}
                </div>
              </div>

              {/* Info */}
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg text-xs text-muted-foreground space-y-1">
                <p>💡 提示：您可以複製這些提示詞用於其他 AI 圖像生成工具</p>
                <p>當前權重倍數：{weightMultiplier.toFixed(1)}x</p>
              </div>

              <Button
                onClick={() => setShowPromptPreview(false)}
                className="w-full"
              >
                關閉
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
