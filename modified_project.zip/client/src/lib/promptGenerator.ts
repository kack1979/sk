/**
 * Advanced Prompt Generator with V4 MASTER STYLE Keywords
 * Supports random inspiration and weight adjustment
 */

// V4 MASTER STYLE Keywords organized by category
export const V4_KEYWORDS = {
  styleWeights: {
    character: "(Korean AAA MMORPG Character Design:1.5)",
    rendering: "(Premium Korean Character Rendering:1.5)",
    skin: "(UE5 Character Skin Shader:1.4)",
    quality: "(High-End Korean 3D Semi-Realistic Character:1.4)",
    art: "(Game Splash Art Quality:1.4)",
    lighting: "(Professional Portrait Lighting:1.2)",
  },

  quality: [
    "masterpiece",
    "best quality",
    "amazing quality",
    "ultra detailed",
    "absurdres",
    "8K",
    "HDR",
  ],

  style: [
    "75% Korean AAA MMORPG Character",
    "25% Premium Professional Portrait Photography",
    "Korean 3D Semi-Realistic Character",
    "Premium Korean Game Character",
    "AAA MMORPG Character Design",
    "AAA Game Splash Art",
    "Unreal Engine 5 Character Rendering",
    "Cinematic CGI",
    "High-End Character Illustration",
    "Luxury Character Artwork",
    "Premium Korean Fantasy Art",
    "Modern Korean Character Aesthetics",
  ],

  face: [
    "beautiful Korean facial proportions",
    "small oval face",
    "soft rounded jawline",
    "slightly full cheeks",
    "delicate chin",
    "gentle youthful adult beauty",
    "natural facial asymmetry",
    "balanced facial features",
  ],

  eyes: [
    "large almond-shaped eyes",
    "slightly droopy eyes",
    "natural double eyelids",
    "deep crystal iris",
    "realistic iris pattern",
    "soft eyelashes",
    "wet eyes",
    "natural catchlight",
    "premium eye shader",
  ],

  mouth: [
    "small elegant nose",
    "soft glossy lips",
    "natural lip gradient",
    "subtle smile",
    "gentle expression",
  ],

  skin: [
    "Premium Korean UE5 Skin Shader",
    "Ultra Smooth Porcelain Skin",
    "High Quality Subsurface Scattering",
    "SSS",
    "Soft Skin Translucency",
    "Healthy Pink Undertone",
    "Soft Natural Blush",
    "Natural Skin Highlights",
    "Silky Smooth Skin",
    "Luxury Skin Rendering",
    "Fine Skin Gradient",
    "Soft Specular",
    "High-End Character Skin",
  ],

  hair: [
    "Ultra Detailed Hair",
    "Individual Hair Strands",
    "Fine Flyaway Hair",
    "Layered Hair",
    "Volumetric Hair",
    "Realistic Hair Shader",
    "PBR Hair",
    "Silky Hair",
    "Natural Hair Scattering",
    "Soft Hair Highlights",
  ],

  materials: [
    "Physically Based Rendering",
    "PBR Materials",
    "Realistic Fabric Texture",
    "Luxury Satin",
    "Soft Silk",
    "Organza",
    "Micro Fabric Details",
    "High-End Material Rendering",
  ],

  lighting: [
    "85mm Portrait Lens",
    "Professional Portrait Composition",
    "Cinematic Composition",
    "Shallow Depth of Field",
    "Luxury Portrait Lighting",
    "Warm Indoor Light",
    "Cool Window Rim Light",
    "Global Illumination",
    "Ray Tracing",
    "Volumetric Lighting",
    "Soft Shadow Transition",
    "High Dynamic Range",
    "Cinematic Color Grading",
  ],

  final: [
    "AAA Promotional Artwork",
    "Highest Quality Character Rendering",
    "Game Key Visual",
    "Luxury Korean Character Illustration",
    "Next Generation Character Rendering",
    "Hyper Detailed Character",
    "Sharp Focus",
  ],
};

export const NEGATIVE_KEYWORDS = [
  "worst quality",
  "low quality",
  "normal quality",
  "lowres",
  "blurry",
  "jpeg artifacts",
  "pixelated",
  "noise",
  "photorealistic",
  "real person",
  "real human",
  "real face",
  "real skin",
  "DSLR",
  "phone camera",
  "selfie",
  "snapshot",
  "fashion model",
  "fashion magazine",
  "runway",
  "editorial photography",
  "beauty influencer",
  "Instagram",
  "TikTok",
  "K-pop idol",
  "celebrity",
  "cosplay",
  "western face",
  "western beauty",
  "aged face",
  "old face",
  "over 25 years old",
  "masculine",
  "child",
  "baby face",
  "anime",
  "2D",
  "manga",
  "comic",
  "cartoon",
  "cel shading",
  "flat color",
  "plastic skin",
  "wax skin",
  "doll",
  "mannequin",
  "rubber skin",
  "visible pores",
  "skin blemishes",
  "acne",
  "freckles",
  "heavy makeup",
  "over sharpen",
  "over saturated",
  "bad anatomy",
  "deformed",
  "mutated",
  "bad hands",
  "extra fingers",
  "missing fingers",
  "cross eye",
  "lazy eye",
  "duplicate",
  "cropped",
  "watermark",
  "logo",
  "signature",
  "text",
];

/**
 * Generate random inspiration prompt from V4 keywords
 */
export function generateRandomInspiration(): string {
  const randomFromArray = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

  const parts: string[] = [];

  // Add quality keywords
  parts.push(`(${V4_KEYWORDS.quality.slice(0, 3).join(", ")})`);

  // Add random style
  parts.push(randomFromArray(V4_KEYWORDS.style));

  // Add random face description
  parts.push(randomFromArray(V4_KEYWORDS.face));

  // Add random eye description
  parts.push(randomFromArray(V4_KEYWORDS.eyes));

  // Add random mouth description
  parts.push(randomFromArray(V4_KEYWORDS.mouth));

  // Add random skin description
  parts.push(randomFromArray(V4_KEYWORDS.skin));

  // Add random hair description
  parts.push(randomFromArray(V4_KEYWORDS.hair));

  // Add random material description
  parts.push(randomFromArray(V4_KEYWORDS.materials));

  // Add random lighting description
  parts.push(randomFromArray(V4_KEYWORDS.lighting));

  // Add final quality keywords
  parts.push(randomFromArray(V4_KEYWORDS.final));

  return parts.join(", ");
}

/**
 * Build enhanced prompt with weight adjustment
 * weightMultiplier: 0.5 to 2.0 (0.5 = half strength, 1.0 = normal, 2.0 = double strength)
 */
export function buildEnhancedPromptWithWeights(
  basePrompt: string,
  weightMultiplier: number = 1.0
): string {
  const adjustWeight = (weight: number): number => {
    const base = parseFloat(weight.toString());
    return Math.round((base * weightMultiplier) * 10) / 10;
  };

  // Build weighted style prefix
  const weightedPrefix = [
    `(Korean AAA MMORPG Character Design:${adjustWeight(1.5)})`,
    `(Premium Korean Character Rendering:${adjustWeight(1.5)})`,
    `(UE5 Character Skin Shader:${adjustWeight(1.4)})`,
    `(High-End Korean 3D Semi-Realistic Character:${adjustWeight(1.4)})`,
    `(Game Splash Art Quality:${adjustWeight(1.4)})`,
    `(Professional Portrait Lighting:${adjustWeight(1.2)})`,
  ].join(", ");

  // Combine with base prompt
  let enhanced = `${weightedPrefix}, ${basePrompt}`;

  // Add age limit
  enhanced += ", age 18-25 years old, youthful appearance";

  // Add photography keywords with adjusted weights
  const photographyKeywords = [
    `(Professional Portrait Composition:${adjustWeight(1.2)})`,
    `(Cinematic Composition:${adjustWeight(1.1)})`,
    `(Shallow Depth of Field:${adjustWeight(1.1)})`,
    `(Luxury Portrait Lighting:${adjustWeight(1.2)})`,
    `(Ray Tracing:${adjustWeight(1.0)})`,
    `(Volumetric Lighting:${adjustWeight(1.0)})`,
    `(High Dynamic Range:${adjustWeight(1.0)})`,
    `(Cinematic Color Grading:${adjustWeight(1.0)})`,
  ].join(", ");

  enhanced += `, ${photographyKeywords}`;

  return enhanced;
}

/**
 * Replace sensitive words with professional photography terminology
 */
export function replaceSensitiveWords(text: string): string {
  const replacements: Record<string, string> = {
    sexy: "artistic and elegant",
    seductive: "captivating and refined",
    revealing: "artistically exposed",
    suggestive: "artistic interpretation",
    "deep cleavage": "artistic chest exposure",
    "plunging neckline": "sophisticated neckline design",
    exposed: "artistically revealed",
    sensual: "graceful and refined",
    provocative: "artistic and bold",
  };

  let result = text;
  for (const [sensitive, replacement] of Object.entries(replacements)) {
    const regex = new RegExp(`\\b${sensitive}\\b`, "gi");
    result = result.replace(regex, replacement);
  }
  return result;
}

/**
 * Build complete negative prompt
 */
export function buildNegativePrompt(): string {
  return `(${NEGATIVE_KEYWORDS.slice(0, 10).join(", ")})`;
}

/**
 * Format prompt for display with line breaks
 */
export function formatPromptForDisplay(prompt: string): string {
  // Split by comma and add line breaks for readability
  return prompt
    .split(",")
    .map((part) => part.trim())
    .filter((part) => part.length > 0)
    .join("\n");
}
