# 韓系 3D COS 生成器 - Windows 打包指南

## 快速開始（3 步驟）

### 第 1 步：安裝 Node.js
1. 訪問 https://nodejs.org/
2. 下載 **LTS 版本**（推薦 v20 或以上）
3. 運行安裝程序，按照提示完成安裝
4. 安裝完成後，**重啟電腦**

### 第 2 步：準備源代碼
1. 將 `korean-3d-cos-generator` 文件夾解壓到任意位置（例如 `C:\Users\YourName\Desktop\`）
2. 在該文件夾中看到 `build-windows.bat` 文件

### 第 3 步：運行打包腳本
1. 在 `korean-3d-cos-generator` 文件夾中，找到 `build-windows.bat`
2. **雙擊** 該文件
3. 等待打包完成（通常需要 3-5 分鐘）
4. 完成後會自動打開文件夾，您會看到生成的 `.exe` 文件

## 安裝應用

打包完成後，您會在 `dist_electron` 文件夾中看到：
- **韓系 3D COS 生成器 Setup 1.0.0.exe** （推薦使用）

雙擊該文件即可安裝應用到您的 Windows 10。

## 常見問題

### Q: 運行 build-windows.bat 時出現 "pnpm: command not found"
**A:** 需要先安裝 pnpm（Node.js 包管理器）
```bash
npm install -g pnpm
```

### Q: 打包過程中出現錯誤
**A:** 
1. 確保已安裝最新的 Node.js
2. 刪除 `node_modules` 文件夾和 `pnpm-lock.yaml`
3. 重新運行 `build-windows.bat`

### Q: 生成的 .exe 無法運行
**A:**
1. 確保 Windows Defender 或其他防病毒軟件未阻止
2. 右鍵點擊 .exe，選擇「以管理員身份運行」
3. 如果仍無法運行，請檢查 Windows 版本是否為 Windows 10 或更新

## 技術細節

- **框架**：Electron 43.1.1
- **Node.js 要求**：v16 或以上
- **包管理器**：pnpm
- **構建工具**：electron-builder

## 支持

如遇到問題，請保留錯誤信息並聯繫開發者。
