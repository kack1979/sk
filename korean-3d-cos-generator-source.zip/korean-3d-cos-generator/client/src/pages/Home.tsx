import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Download, Eye, ImageIcon, Loader2, X } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Home() {
  const { user } = useAuth();

  // 參數狀態
  const [hairColor, setHairColor] = useState("blonde");
  const [eyeColor, setEyeColor] = useState("blue");
  const [clothing, setClothing] = useState("dress");
  const [bustSize, setBustSize] = useState("D");
  const [customPrompt, setCustomPrompt] = useState("");
  const [autoOptimize, setAutoOptimize] = useState(true);
  const [weightMultiplier, setWeightMultiplier] = useState(1.0);

  // UI 狀態
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewPrompt, setPreviewPrompt] = useState<{ positive: string; negative: string } | null>(null);
  const [showPromptPreview, setShowPromptPreview] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<Array<{ id: string; url: string }>>([]);
  const [lightboxImage, setLightboxImage] = useState("");
  const [lightboxOpen, setLightboxOpen] = useState(false);

  // tRPC 調用
  const buildPromptMutation = trpc.cosImage.buildPrompt.useMutation();
  const generateImageMutation = trpc.cosImage.generateImage.useMutation();

  // 預覽提示詞
  const handlePreviewPrompt = async () => {
    try {
      const result = await buildPromptMutation.mutateAsync({
        hairColor,
        eyeColor,
        expressions: [],
        accessories: [],
        clothing,
        bustSize,
        customPrompt,
        autoOptimize,
      });

      setPreviewPrompt({
        positive: result.positivePrompt,
        negative: result.negativePrompt,
      });
      setShowPromptPreview(true);
    } catch (error) {
      toast.error("預覽失敗");
    }
  };

  // 生成圖像
  const handleGenerateImage = async () => {
    if (!clothing) {
      toast.error("請先選擇服裝類型");
      return;
    }

    setIsGenerating(true);
    try {
      const promptResult = await buildPromptMutation.mutateAsync({
        hairColor,
        eyeColor,
        expressions: [],
        accessories: [],
        clothing,
        bustSize,
        customPrompt,
        autoOptimize,
      });

      const imageResult = await generateImageMutation.mutateAsync({
        positivePrompt: promptResult.positivePrompt,
        negativePrompt: promptResult.negativePrompt,
      });

      if (imageResult.imageUrl && imageResult.success) {
        setGeneratedImages((prev) => [
          { id: Date.now().toString(), url: imageResult.imageUrl! },
          ...prev,
        ]);
        toast.success("圖像生成成功！");
      }
    } catch (error) {
      console.error("Generation error:", error);
      toast.error(`生成失敗: ${error instanceof Error ? error.message : "未知錯誤"}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // 下載圖像
  const handleDownloadImage = (url: string) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = `cos-image-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex h-screen flex-col lg:flex-row">
        {/* 左側面板 - 參數設定 */}
        <div className="w-full lg:w-96 overflow-y-auto bg-card border-r border-border p-6 space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-accent mb-2">韓系 3D COS 生成器</h1>
            <p className="text-sm text-muted-foreground">AI 驅動的角色圖像生成工具</p>
          </div>

          {/* 髮色選擇 */}
          <div className="space-y-2">
            <Label htmlFor="hair-color">髮色</Label>
            <Select value={hairColor} onValueChange={setHairColor}>
              <SelectTrigger id="hair-color">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="black">黑色</SelectItem>
                <SelectItem value="brown">棕色</SelectItem>
                <SelectItem value="blonde">金色</SelectItem>
                <SelectItem value="red">紅色</SelectItem>
                <SelectItem value="purple">紫色</SelectItem>
                <SelectItem value="pink">粉紅色</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 眼色選擇 */}
          <div className="space-y-2">
            <Label htmlFor="eye-color">眼色</Label>
            <Select value={eyeColor} onValueChange={setEyeColor}>
              <SelectTrigger id="eye-color">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="blue">藍色</SelectItem>
                <SelectItem value="brown">棕色</SelectItem>
                <SelectItem value="green">綠色</SelectItem>
                <SelectItem value="purple">紫色</SelectItem>
                <SelectItem value="red">紅色</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 服裝選擇 */}
          <div className="space-y-2">
            <Label htmlFor="clothing">服裝</Label>
            <Select value={clothing} onValueChange={setClothing}>
              <SelectTrigger id="clothing">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dress">禮服</SelectItem>
                <SelectItem value="casual">休閒裝</SelectItem>
                <SelectItem value="school">校服</SelectItem>
                <SelectItem value="maid">女僕裝</SelectItem>
                <SelectItem value="kimono">和服</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 胸圍選擇 */}
          <div className="space-y-2">
            <Label htmlFor="bust-size">胸圍</Label>
            <Select value={bustSize} onValueChange={setBustSize}>
              <SelectTrigger id="bust-size">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="B">B</SelectItem>
                <SelectItem value="C">C</SelectItem>
                <SelectItem value="D">D</SelectItem>
                <SelectItem value="E">E</SelectItem>
                <SelectItem value="F">F</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 自定義提示詞 */}
          <div className="space-y-2">
            <Label htmlFor="custom-prompt">自定義提示詞</Label>
            <Textarea
              id="custom-prompt"
              placeholder="輸入額外的提示詞..."
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              className="min-h-20"
            />
          </div>

          {/* 權重調整 */}
          <div className="space-y-2">
            <Label>權重倍數: {weightMultiplier.toFixed(1)}x</Label>
            <Slider
              value={[weightMultiplier]}
              onValueChange={(value) => setWeightMultiplier(value[0])}
              min={0.5}
              max={2.0}
              step={0.1}
              className="w-full"
            />
          </div>

          {/* 自動優化開關 */}
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="auto-optimize"
              checked={autoOptimize}
              onChange={(e) => setAutoOptimize(e.target.checked)}
              className="w-4 h-4"
            />
            <Label htmlFor="auto-optimize" className="cursor-pointer">
              自動優化提示詞
            </Label>
          </div>

          {/* 按鈕組 */}
          <div className="space-y-2">
            <Button
              onClick={handlePreviewPrompt}
              variant="outline"
              className="w-full"
            >
              <Eye className="mr-2 h-4 w-4" />
              預覽提示詞
            </Button>
            <Button
              onClick={handleGenerateImage}
              disabled={isGenerating || !clothing}
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-6 text-lg"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  生成中...
                </>
              ) : (
                <>
                  <ImageIcon className="w-5 h-5 mr-2" />
                  生成圖像
                </>
              )}
            </Button>
          </div>
        </div>

        {/* 右側面板 - 預覽與歷史 */}
        <div className="flex-1 overflow-y-auto bg-background p-6">
          <Tabs defaultValue="preview" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-card border border-border">
              <TabsTrigger value="preview" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <ImageIcon className="w-4 h-4 mr-2" />
                預覽
              </TabsTrigger>
              <TabsTrigger value="history" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
                <ImageIcon className="w-4 h-4 mr-2" />
                歷史
              </TabsTrigger>
            </TabsList>

            {/* 預覽分頁 */}
            <TabsContent value="preview" className="mt-6">
              {generatedImages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <ImageIcon className="w-16 h-16 text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">還沒有生成任何圖像</p>
                  <p className="text-sm text-muted-foreground/70">調整參數後點擊「生成圖像」開始</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {generatedImages.map((img) => (
                    <div
                      key={img.id}
                      className="group relative aspect-square rounded-lg overflow-hidden bg-card border border-border cursor-pointer hover:border-accent transition"
                      onClick={() => {
                        setLightboxImage(img.url);
                        setLightboxOpen(true);
                      }}
                    >
                      <img
                        src={img.url}
                        alt="generated"
                        className="w-full h-full object-cover group-hover:scale-105 transition"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadImage(img.url);
                          }}
                          className="bg-accent hover:bg-accent/90 text-accent-foreground"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setGeneratedImages((prev) => prev.filter((i) => i.id !== img.id));
                          }}
                          className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* 歷史分頁 */}
            <TabsContent value="history" className="mt-6">
              <div className="text-center py-12 text-muted-foreground">
                <p>歷史記錄功能即將推出</p>
                {!user && <p className="text-sm mt-2">登入後可查看生成歷史</p>}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* 燈箱 */}
      {lightboxOpen && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
          onClick={() => setLightboxOpen(false)}
        >
          <div className="relative max-w-4xl max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
            <img
              src={lightboxImage}
              alt="lightbox"
              className="w-full h-full object-contain"
            />
            <Button
              size="sm"
              variant="ghost"
              className="absolute top-4 right-4 bg-background/80 hover:bg-background"
              onClick={() => setLightboxOpen(false)}
            >
              <X className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              className="absolute bottom-4 right-4 bg-accent hover:bg-accent/90"
              onClick={() => handleDownloadImage(lightboxImage)}
            >
              <Download className="w-4 h-4 mr-2" />
              下載
            </Button>
          </div>
        </div>
      )}

      {/* 提示詞預覽模態框 */}
      {showPromptPreview && previewPrompt && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowPromptPreview(false)}
        >
          <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto bg-card">
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold">提示詞預覽</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPromptPreview(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label className="text-base font-semibold">正向提示詞</Label>
                <div className="bg-background p-4 rounded-lg border border-border text-sm break-words max-h-40 overflow-y-auto">
                  {previewPrompt.positive}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    navigator.clipboard.writeText(previewPrompt.positive);
                    toast.success("已複製到剪貼板");
                  }}
                >
                  複製正向提示詞
                </Button>
              </div>

              <div className="space-y-2">
                <Label className="text-base font-semibold">負向提示詞</Label>
                <div className="bg-background p-4 rounded-lg border border-border text-sm break-words max-h-40 overflow-y-auto">
                  {previewPrompt.negative}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    navigator.clipboard.writeText(previewPrompt.negative);
                    toast.success("已複製到剪貼板");
                  }}
                >
                  複製負向提示詞
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
