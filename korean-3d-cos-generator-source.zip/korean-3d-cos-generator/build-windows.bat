@echo off
chcp 65001 >nul
echo ========================================
echo 韓系 3D COS 生成器 - Windows 打包工具
echo ========================================
echo.

REM 檢查 Node.js
echo [1/5] 檢查 Node.js...
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 錯誤：未找到 Node.js
    echo 請先安裝 Node.js: https://nodejs.org/
    pause
    exit /b 1
)
echo ✓ Node.js 已安裝

REM 安裝依賴
echo.
echo [2/5] 安裝依賴...
call pnpm install
if errorlevel 1 (
    echo ❌ 安裝依賴失敗
    pause
    exit /b 1
)
echo ✓ 依賴安裝完成

REM 構建應用
echo.
echo [3/5] 構建應用...
call pnpm run build
if errorlevel 1 (
    echo ❌ 構建失敗
    pause
    exit /b 1
)
echo ✓ 應用構建完成

REM 打包 Windows 應用
echo.
echo [4/5] 打包 Windows 應用...
call pnpm run electron:build:win
if errorlevel 1 (
    echo ❌ 打包失敗
    pause
    exit /b 1
)
echo ✓ Windows 應用打包完成

REM 完成
echo.
echo [5/5] 完成！
echo.
echo ========================================
echo ✓ 打包完成！
echo ========================================
echo.
echo 您的應用程序已生成在：
echo dist_electron\韓系 3D COS 生成器 Setup 1.0.0.exe
echo.
echo 雙擊該文件即可安裝應用
echo.
pause
