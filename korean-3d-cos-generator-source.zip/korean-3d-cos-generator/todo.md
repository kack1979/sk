# 韓系 3D COS 角色 AI 圖像生成平台 - Windows 桌面應用開發清單

## 第一階段：UI 與主題配置
- [x] 配置深色主題（dark mode）與粉紫色 accent 色彩系統
- [x] 設定全局 CSS 變量與 Tailwind 主題
- [ ] 導入韓系遊戲風格字體與視覺元素

## 第二階段：數據庫與後端架構
- [x] 設計 generatedImages 表（用戶、提示詞、圖像 URL、參數）
- [x] 設計 referenceImages 表（用戶上傳的參考圖）
- [x] 創建 tRPC 路由：cosImage.buildPrompt
- [x] 創建 tRPC 路由：cosImage.generateImage
- [x] 創建 tRPC 路由：cosImage.saveImage
- [x] 創建 tRPC 路由：cosImage.getHistory
- [x] 創建 tRPC 路由：cosImage.deleteImage
- [x] 創建 tRPC 路由：cosImage.uploadReferenceImage

## 第三階段：前端參數設定與提示詞
- [ ] 開發參數設定面板（髮色、眼色、表情、配件、服裝、場景、角度、姿勢、胸圍）
- [ ] 實現隨機靈感生成功能
- [ ] 實現權重調整滑桿（0.5x - 2.0x）
- [ ] 開發提示詞預覽模態框
- [ ] 實現提示詞複製功能

## 第四階段：AI 圖像生成
- [ ] 集成內建 Image Generation API
- [ ] 實現參考圖上傳功能
- [ ] 實現圖像生成進度顯示
- [ ] 配置 S3 存儲集成

## 第五階段：歷史記錄與預覽
- [ ] 開發生成歷史記錄頁面
- [ ] 實現燈箱（Lightbox）全屏預覽
- [ ] 實現圖像下載功能
- [ ] 實現歷史記錄刪除功能
- [ ] 實現歷史記錄分頁加載

## 第六階段：Electron 桌面應用打包（Windows）
- [ ] 安裝 Electron 依賴
- [ ] 配置 electron-builder 用於 Windows 打包
- [ ] 設置應用圖標和安裝程序配置
- [ ] 構建 Windows .exe 文件
- [ ] 測試 .exe 文件在 Windows 10 上的運行

## 進度追蹤
- 當前階段：第一階段 - 前端 UI 開發
- 完成度：30%（主題配置完成，正在開發 UI 組件）
