import { contextBridge, ipcMain } from "electron";

contextBridge.exposeInMainWorld("electron", {
  app: {
    getVersion: () => ipcMain.invoke("app:getVersion"),
    getPath: (name: string) => ipcMain.invoke("app:getPath", name),
  },
});
